<template>
  <div class="flex flex-col justify-center items-center p-10">
    <h2>Simple private file sharing</h2>
    <img class="h-[15rem]" src="/images/monitoring.png" alt="" />
    <p class="my-1">
      Welcome to online data transfer, the world's leading private file sharing
      website. Just select file enter recipient's email id and boom! a private
      link will be share with the recipient and then the file can be downloaded
      with a single click, don't worry its 100% safe and secure your files will
      be encrypted.
    </p>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>