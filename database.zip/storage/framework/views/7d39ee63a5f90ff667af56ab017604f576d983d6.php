<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>D Transfer</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="<?php echo e(mix('/css/app.css')); ?>"></link>

    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }

    </style>
</head>

<body>
    <div id="app">
        <App route="<?php echo e(route('upload')); ?>" />
    </div>
    <script src="<?php echo e(mix('/js/app.js')); ?>"></script>

</body>

</html>
<?php /**PATH D:\Workspace\OnlineDataTransfer\online-data-transfer\resources\views/welcome.blade.php ENDPATH**/ ?>